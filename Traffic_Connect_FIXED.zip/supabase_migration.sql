-- Traffic Connect — إضافة جدولين جديدين لتفعيل:
-- 1) تقييم المهندس على كل موعد
-- 2) التعليق العام على التطبيق
-- شغّل هذا الملف مرة واحدة فقط من Supabase Dashboard → SQL Editor → New query → Run

create extension if not exists pgcrypto;

-- =========================================================
-- 1) appointment_ratings: تقييم المقاول للمهندس بعد كل موعد
-- =========================================================
create table if not exists public.appointment_ratings (
  id uuid primary key default gen_random_uuid(),
  appointment_id uuid not null references public.appointments(id) on delete cascade,
  contractor_id uuid not null references auth.users(id) on delete cascade,
  engineer_id uuid not null references public.engineers(id) on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique (appointment_id)
);

alter table public.appointment_ratings enable row level security;

-- المقاول يقدر يضيف تقييم فقط لموعد يخصه وتم تأكيده/اكتماله
create policy "contractor insert own rating"
  on public.appointment_ratings for insert
  with check (
    contractor_id = auth.uid()
    and exists (
      select 1 from public.appointments a
      where a.id = appointment_id
        and a.contractor_id = auth.uid()
        and a.status in ('accepted','completed')
    )
  );

-- المقاول يقدر يعدّل تقييمه هو فقط
create policy "contractor update own rating"
  on public.appointment_ratings for update
  using (contractor_id = auth.uid())
  with check (contractor_id = auth.uid());

-- المقاول يشوف تقييماته هو فقط
create policy "contractor select own rating"
  on public.appointment_ratings for select
  using (contractor_id = auth.uid());

-- المهندس يشوف التقييمات المتعلقة فيه (إذا عندك ربط user_id بجدول engineers)
create policy "engineer select own ratings"
  on public.appointment_ratings for select
  using (engineer_id in (select id from public.engineers where user_id = auth.uid()));

-- تحديث تلقائي لمعدل تقييم المهندس (عمود rating) في جدول engineers
create or replace function public.tc_update_engineer_rating()
returns trigger
language plpgsql
security definer
as $$
begin
  update public.engineers e
  set rating = (
    select round(avg(rating)::numeric,1)
    from public.appointment_ratings
    where engineer_id = coalesce(new.engineer_id, old.engineer_id)
  )
  where e.id = coalesce(new.engineer_id, old.engineer_id);
  return null;
end;
$$;

drop trigger if exists trg_update_engineer_rating on public.appointment_ratings;
create trigger trg_update_engineer_rating
after insert or update or delete on public.appointment_ratings
for each row execute function public.tc_update_engineer_rating();


-- =========================================================
-- 2) app_feedback: تعليق عام على التطبيق (تقييم + رأي)
-- =========================================================
create table if not exists public.app_feedback (
  id uuid primary key default gen_random_uuid(),
  contractor_id uuid not null references auth.users(id) on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  comment text not null,
  created_at timestamptz not null default now()
);

alter table public.app_feedback enable row level security;

-- أي مستخدم مسجّل دخول يقدر يضيف تعليقه هو فقط
create policy "authenticated insert own feedback"
  on public.app_feedback for insert
  with check (contractor_id = auth.uid());

-- كل التعليقات تظهر للجميع (تعليق عام)
create policy "authenticated read all feedback"
  on public.app_feedback for select
  using (auth.uid() is not null);
